"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle,CardSubTitle1, CardSubTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { ExternalLink, Download, ArrowRight, Github, Linkedin, Mail, Code, Database, Palette, Link } from "lucide-react"
import { Typewriter } from "@/components/typewriter"

export default function Portfolio() {
  return (
    <div className="min-h-screen bg-white">
      <nav className="fixed top-0 w-full bg-white/95 backdrop-blur-sm border-b border-slate-200 z-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <div className="text-2xl font-bold text-slate-900 tracking-tight">
              <Typewriter text="Muralidharan Pakkirisamy" speed={150} loop={true} />
            </div>
            <div className="hidden md:flex space-x-10">
              <a href="#about" className="text-slate-600 hover:text-slate-900 transition-colors font-medium">
                About
              </a>
              <a href="#projects" className="text-slate-600 hover:text-slate-900 transition-colors font-medium">
                Projects
              </a>
              <a href="#expertise" className="text-slate-600 hover:text-slate-900 transition-colors font-medium">
                Expertise
              </a>
              <a href="#contact" className="text-slate-600 hover:text-slate-900 transition-colors font-medium">
                Contact
              </a>
            </div>
          </div>
        </div>
      </nav>

      <section className="pt-32 pb-24 bg-gradient-to-br from-slate-50 to-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-6xl md:text-7xl font-bold text-slate-900 mb-6 tracking-tight">
              <Typewriter text="Muralidharan Pakkirisamy" speed={150} loop={true} />
            </h1>
            <p className="text-2xl md:text-3xl text-slate-600 mb-8 font-light">
              <Typewriter text="Senior Full-Stack Developer" speed={80} loop={true} />
            </p>
            <p className="text-xl text-slate-600 mb-12 max-w-3xl mx-auto leading-relaxed">
              Crafting exceptional digital experiences through innovative technology solutions and user-centered design
              principles
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-slate-900 hover:bg-slate-800 text-white px-8 py-3 text-base font-medium">
                Explore My Work
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="border-slate-300 text-slate-700 hover:bg-slate-50 px-8 py-3 text-base bg-transparent"
              >
                <Download className="w-4 h-4 mr-2" />
                Download CV
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section id="about" className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="relative">
              <img
                src="/professional-headshot-of-a-developer.jpg"
                alt="Professional headshot"
                className="rounded-2xl shadow-2xl w-full max-w-lg mx-auto"
              />
            </div>
            <div className="space-y-8">
              <div>
                <h2 className="text-5xl font-bold text-slate-900 mb-6 tracking-tight">About Me</h2>
                <div className="w-20 h-1 bg-blue-600 mb-8"></div>
              </div>
              <p className="text-xl text-slate-600 leading-relaxed font-light">
                      Results-driven and detail-oriented Full Stack Software Developer with over 12 years of hands on experience in architecting, developing, and delivering robust, scalable, and high-performance 
                      applications using Microsoft technologies. Specialized in <b>.NET Core-based enterprise solutions 
                      with a proven track record in full-stack development across multiple industries including finance, 
                      healthcare, and e-commerce.</b> 
              </p>
              <p className="text-lg text-slate-600 leading-relaxed">
                      Deep expertise in building cloud-native applications using <b>
                      ASP.NET Core, Web API, Azure services </b>, and modern front-end frameworks such as <b>Angular 
                      ,ReactJS and NextJS</b>. Adept at <b>Agile methodologies, Microservices,  clean code practices, and driving software 
                      development</b> from concept to deployment. Actively seeking impactful software development 
                      roles where deep .NET Core expertise and system architecture skills are valued
              </p>
              <div className="flex flex-wrap gap-4 pt-4">
                  <Button
                    asChild
                    variant="outline"
                    className="border-slate-300 text-slate-700 hover:bg-slate-100 bg-transparent"
                  >
                    <Link href="https://github.com/muralidharan84" target="_blank" className="flex items-center">
                      <Github className="w-4 h-4 mr-2" />
                      Github
                    </Link>
                  </Button>
                <Button variant="outline" className="border-slate-300 text-slate-700 hover:bg-slate-100 bg-transparent">
                  <Linkedin className="w-4 h-4 mr-2" />
                  LinkedIn
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="projects" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold text-slate-900 mb-6 tracking-tight">
              <Typewriter text="Featured Projects" speed={100} loop={true} />
            </h2>
            <div className="w-20 h-1 bg-blue-600 mx-auto mb-6"></div>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
              A selection of recent work showcasing technical expertise and creative problem-solving
            </p>
          </div>
          <div className="grid lg:grid-cols-3 gap-8">
            {[
              {
                title: "Tawtheeq / Mservices – Tenancy Management System",
                subtitle: ["Jun 2018 – Dec 2018","Client: AlAin Municipality"],
                description: ["Developed a digital tenancy management system similar to Dubai’s Ejari, enabling government regulation of rental contracts to ensure transparency and prevent disputes between landlords and tenants",
                              "Streamlined all rental transactions in Abu Dhabi through a bilingual (English/Arabic) repository of apartments and villas for rent",
                              "Implemented procedures for registering new rental agreements while ensuring compliance with government regulations",
                              "Leveraged modern technologies to simplify workflows, enhance data accuracy, and maintain high-quality records",
                              "Enabled tenants, landlords, and administrators to access verified information efficiently, reducing conflicts and improving overall rental management",
                ],
                image: "/preview/Gov-Project.png",
                tags: ["Angular",".Net Core", "HTML 5", "Bootstrap", "RestAPI","Sql Server"],
                metrics: "Sub-second query response",
                github: "#",
                live: "https://www.hsn.com/",
              },
              {
                title: "AAMRO Freight Management System",
                subtitle: ["Jun 2017 – Jun 2018","Client: AAMRO Freight & Shipping Services LLC"],
                description: ["Developed a comprehensive freight and logistics management application to streamline shipment tracking, cargo scheduling, and delivery operations",
                              "Enabled users to manage inbound and outbound shipments, track containers, and monitor delivery status in real time",
                              "Integrated modules for invoice generation, billing, and reporting to improve operational transparency and accuracy",
                              "Implemented search and filtering features to quickly locate shipments, consignment details, and customer records",
                              "Designed dashboards and analytics to provide insights on shipment performance, delays, and resource utilization"
                ],
                image: "/preview/fms1.png",
                tags: ["Vue.js", "D3.js", "WebSocket", "ClickHouse", "Docker"],
                metrics: "Sub-second query response",
                github: "#",
                live: "https://www.hsn.com/",
              },
             {
                title: "Warehouse Management System (WMS)",
                subtitle: ["Nov 2016 – Jun 2017","Client: AAMRO Freight & Shipping Services LLC"],
                description: ["Developed a Warehouse Management System to streamline supply chain operations including receiving, put-away, picking, and shipping of inventory",
                              "Enabled users to manage inbound and outbound orders with detailed part information, and monitor pending orders through intuitive menus",
                              "Implemented search functionality to locate parts by part number or serial number and identify their storage bins",
                              "Provided complete bin and inventory details for effective warehouse tracking",
                              "Designed and integrated a pick list generation feature, allowing users to print part and bin details for faster order fulfillment",
                              "Improved operational efficiency and accuracy in warehouse management through a user-friendly application"
                ],
                image: "/preview/project4.png",
                tags: ["Angular",".Net Core", "HTML 5", "Bootstrap", "RestAPI","Sql Server"],
                metrics: "Sub-second query response",
                github: "#",
                live: "https://www.hsn.com/",
              },
              {
                title: "Tawtheeq / Mservices – Tenancy Management System",
                subtitle: ["Jun 2018 – Dec 2018","Client: AlAin Municipality"],
                description: ["Developed a digital tenancy management system similar to Dubai’s Ejari, enabling government regulation of rental contracts to ensure transparency and prevent disputes between landlords and tenants",
                              "Streamlined all rental transactions in Abu Dhabi through a bilingual (English/Arabic) repository of apartments and villas for rent",
                              "Implemented procedures for registering new rental agreements while ensuring compliance with government regulations",
                              "Leveraged modern technologies to simplify workflows, enhance data accuracy, and maintain high-quality records",
                              "Enabled tenants, landlords, and administrators to access verified information efficiently, reducing conflicts and improving overall rental management",
                ],
                image: "/preview/project4.png",
                tags: ["Angular",".Net Core", "HTML 5", "Bootstrap", "RestAPI","Sql Server"],
                metrics: "Sub-second query response",
                github: "#",
                live: "https://www.hsn.com/",
              },
              {
                title: "AAMRO Freight Management System",
                subtitle: ["Jun 2017 – Jun 2018","Client: AAMRO Freight & Shipping Services LLC"],
                description: ["Developed a comprehensive freight and logistics management application to streamline shipment tracking, cargo scheduling, and delivery operations",
                              "Enabled users to manage inbound and outbound shipments, track containers, and monitor delivery status in real time",
                              "Integrated modules for invoice generation, billing, and reporting to improve operational transparency and accuracy",
                              "Implemented search and filtering features to quickly locate shipments, consignment details, and customer records",
                              "Designed dashboards and analytics to provide insights on shipment performance, delays, and resource utilization"
                ],
                image: "/preview/project4.png",
                tags: ["Vue.js", "D3.js", "WebSocket", "ClickHouse", "Docker"],
                metrics: "Sub-second query response",
                github: "#",
                live: "https://www.hsn.com/",
              },
             {
                title: "Warehouse Management System (WMS)",
                subtitle: ["Nov 2016 – Jun 2017","Client: AAMRO Freight & Shipping Services LLC"],
                description: ["Developed a Warehouse Management System to streamline supply chain operations including receiving, put-away, picking, and shipping of inventory",
                              "Enabled users to manage inbound and outbound orders with detailed part information, and monitor pending orders through intuitive menus",
                              "Implemented search functionality to locate parts by part number or serial number and identify their storage bins",
                              "Provided complete bin and inventory details for effective warehouse tracking",
                              "Designed and integrated a pick list generation feature, allowing users to print part and bin details for faster order fulfillment",
                              "Improved operational efficiency and accuracy in warehouse management through a user-friendly application"
                ],
                image: "/preview/project4.png",
                tags: ["Angular",".Net Core", "HTML 5", "Bootstrap", "RestAPI","Sql Server"],
                metrics: "Sub-second query response",
                github: "#",
                live: "https://www.hsn.com/",
              },
              {
                title: "Finance and Resource Management System (FARM)",
                subtitle: ["Dec 2014 – Oct 2016","Client: Baxter"],
                description: ["Developed a comprehensive financial and resource management tool to manage project resource assignments, billing, and related data",
                              "Implemented features to track project billing, resource allocation, and generate month- and year-wise reports with custom filters",
                              "Enabled managers and PMOs to create and manage Statements of Work (SOW), Purchase Orders (PO), and map resources to projects",
                              "Developed automated notification system to alert managers and PMOs of updates to projects, resources, and billing information",
                              "Streamlined resource and billing management, improving visibility and decision-making for project managers"
                ],
                image: "/preview/project4.png",
                tags: ["Vue.js", "D3.js", "WebSocket", "ClickHouse", "Docker"],
                metrics: "Sub-second query response",
                github: "#",
                live: "https://www.hsn.com/",
              },
              {
                title: "HSN – HTML5 App for LG Connected TV",
                subtitle: ["Jun 2014 – Dec 2014","Client: HSN"],
                description: ["Developed an HTML5-based shopping application for LG Connected TVs, allowing users to browse and purchase products using their TV remote",
                              "Implemented interactive features for product navigation, detailed views, and seamless shopping experience",
                              "Ensured cross-device compatibility and optimized UI for TV screens",
                              "Collaborated with the team to enhance functionality and deliver a responsive, user-friendly e-commerce application"
                ],
                image: "/preview/project4.png",
                tags: ["Vue.js", "D3.js", "WebSocket", "ClickHouse", "Docker"],
                metrics: "Sub-second query response",
                github: "#",
                live: "https://www.hsn.com/",
              },
              {
                title: "HSN – HTML5 App for Dish Hopper Set Top Box",
                subtitle: ["Jan 2014 – Jun 2014","Client: HSN"],
                description: ["Developed an HTML5-based application for Dish Hopper set-top boxes, enabling users to shop directly via their TV using a remote control",
                              "Implemented Views, Controllers, and Services to support smooth navigation and interactive shopping experience",
                              "Collaborated with the team and provided guidance to accelerate development and ensure code quality",
                              "Contributed to building a scalable and user-friendly TV-based e-commerce platform"
                ],
                image: "/preview/project4.png",
                tags: ["Vue.js", "D3.js", "WebSocket", "ClickHouse", "Docker"],
                metrics: "Sub-second query response",
                github: "#",
                live: "https://www.hsn.com/",
              },
               {
                title: "HSN – Online Shopping System",
                subtitle: ["Jan 2013 – Dec 2013","Client: HSN"],
                description: ["Developed an e-commerce platform enabling customers to browse, select, and purchase products and services online",
                              "Implemented product categorization, search, and filtering features to improve user experience",
                              "Integrated secure online payment gateways and delivery service workflows",
                              "Designed the system to expand vendor reach and overcome limitations of traditional retail",
                              "Contributed to creating a scalable platform that streamlined buying and selling processes for a wider market",
                ],
                image: "/preview/project4.png",
                tags: ["MVC 4", "Kendo UI", "Entity framework", "HTML 5", "CSS 3", "OO JavaScript", "jQuery", "Angular", "LINQ", "RESTful API’S"],
                metrics: "Sub-second query response",
                github: "#",
                live: "#",
              },
              {
                title: "Credit Verdict",
                subtitle: ["Aug 2011 – Jan 2013","Client: iScore"],
                description: ["Developed a credit history application to generate positive and negative reports for banking customers",
                                "Automated monthly ingestion of customer data from multiple banks into a centralized bureau.",
                                "Designed and implemented data-matching and validation engines to ensure accuracy and consistency.",
                                "Enabled banks to instantly retrieve customer credit reports during loan applications.",
                                "Supported lending decisions by providing consolidated and reliable credit history insights."],
                image: "/preview/project4.png",
                tags: ["ASP.NET MVC","C#.NET", "SQL", "HTML 5", "CSS 3","OO JavaScript", "jQuery", "LINQ", "RESTful API’S."],
                metrics: "Sub-second query response",
                github: "#",
                live: "#",
              },
               {
                title: "Credit Data Integrity Workflow",
                subtitle: ["Aug 2011 – Jan 2012","Client: iScore"],
                description:["Developed a platform to streamline customer data correction within the Central Bureau (iScore)" ,
                            "Customers initiated correction requests through their banks, which were validated and submitted to the platform",
                            "Automated notifications alerted approvers, who reviewed the requests against existing records and either approved or re-routed them.",
                            "Once approved, updates were seamlessly reflected in the customer’s latest credit report, ensuring accuracy and reliability."],
                image: "/preview/project4.png",
                tags: ["ASP.NET MVC","C#.NET", "SQL", "HTML 5", "CSS 3","OO JavaScript", "jQuery", "LINQ", "RESTful API’S."],
                metrics: "Sub-second query response",
                github: "#",
                live: "https://www.iscore.com.eg/ar/information-for-individuals/home/",
              },
            ].map((project, index) => (
              <Card
                key={index}
                className="group hover:shadow-2xl transition-all duration-500 border-slate-200 hover:border-blue-200 bg-white overflow-hidden"
              >
                <CardHeader className="p-0 relative">
                  <div className="overflow-hidden">
                    <img
                      src={project.image || "/placeholder.svg"}
                      alt={project.title}
                      className="w-full h-56 object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                  </div>
                  <div className="absolute top-4 right-4 bg-blue-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                    {project.metrics}
                  </div>
                </CardHeader>
                <CardContent className="p-8">
                  <CardTitle className="text-2xl mb-3 text-slate-900 group-hover:text-blue-600 transition-colors font-bold">
                    {project.title}
                  </CardTitle>
                  <CardSubTitle items={project.subtitle} className="text-1xl mb-3 text-slate-900 group-hover:text-blue-600 transition-colors font-bold">
                  </CardSubTitle>
                  <CardDescription items={project.description} className="mb-6 text-slate-600 leading-relaxed text-base">
                    
                  </CardDescription>
                  <div className="flex flex-wrap gap-2 mb-6">
                    {project.tags.map((tag, tagIndex) => (
                      <Badge
                        key={tagIndex}
                        className="bg-slate-100 text-slate-700 border-0 px-3 py-1 text-sm font-medium"
                      >
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  <div className="flex gap-3">
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-slate-300 text-slate-700 hover:bg-slate-50 bg-transparent"
                    >
                      <Github className="w-4 h-4 mr-2" />
                      Code
                    </Button>
                    <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-white">
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Live Demo
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section id="expertise" className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold text-slate-900 mb-6 tracking-tight">Technical Expertise</h2>
            <div className="w-20 h-1 bg-blue-600 mx-auto mb-6"></div>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
              Comprehensive skill set spanning modern web technologies and industry best practices
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8 mb-16">
            {[
              {
                icon: <Code className="w-12 h-12 text-blue-600" />,
                title: "Frontend Development",
                description: "Modern React ecosystem with TypeScript, Next.js, and advanced state management",
                skills: ["Angular","React 18", "Next.js 14", "TypeScript", "Tailwind CSS", "Bootstrap", "Framer Motion"],
              },
              {
                icon: <Database className="w-12 h-12 text-blue-600" />,
                title: "Backend & DevOps",
                description: "Scalable server architecture with cloud infrastructure and CI/CD pipelines",
                skills: ["Node.js", "Python", "PostgreSQL", "AWS", "Docker"],
              },
              {
                icon: <Palette className="w-12 h-12 text-blue-600" />,
                title: "Design & UX",
                description: "User-centered design principles with modern prototyping and testing methodologies",
                skills: ["Figma", "Design Systems", "A/B Testing", "Accessibility", "Performance"],
              },
            ].map((area, index) => (
              <Card key={index} className="border-slate-200 bg-white p-8 hover:shadow-lg transition-shadow">
                <div className="mb-6 flex justify-center">{area.icon}</div>
                <CardTitle className="text-2xl mb-4 text-slate-900 font-bold text-center">{area.title}</CardTitle>
                <CardDescription className="mb-6 text-slate-600 leading-relaxed text-base text-center">
                  {area.description}
                </CardDescription>
                <div className="space-y-3">
                  {area.skills.map((skill, skillIndex) => (
                    <div key={skillIndex} className="flex items-center justify-between">
                      <span className="text-slate-700 font-medium">{skill}</span>
                      <div className="w-24 h-2 bg-slate-200 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-blue-500 to-purple-600 rounded-full"
                          style={{ width: `${88 + Math.random() * 12}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section id="contact" className="py-24 bg-white">
        <div className="max-w-6xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold text-slate-900 mb-6 tracking-tight">Let's Work Together</h2>
            <div className="w-20 h-1 bg-blue-600 mx-auto mb-6"></div>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
              Ready to bring your next project to life? Let's discuss how we can create something exceptional together.
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-16">
            <div className="space-y-8">
              <div>
                <h3 className="text-3xl font-bold text-slate-900 mb-6">Get in touch</h3>
                <p className="text-lg text-slate-600 leading-relaxed mb-8">
                  I'm currently available for freelance projects and full-time opportunities. Whether you need a
                  technical consultant, a development partner, or want to discuss an exciting opportunity, I'd love to
                  hear from you.
                </p>
              </div>

              <div className="space-y-6">
                <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-lg">
                  <Mail className="w-6 h-6 text-blue-600" />
                  <div>
                    <div className="font-medium text-slate-900">Email</div>
                    <div className="text-slate-600">murali.itcs@live.com</div>
                  </div>
                </div>
                <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-lg">
                  <Github className="w-6 h-6 text-blue-600" />
                  <div>
                    <div className="font-medium text-slate-900">GitHub</div>
                    <div className="text-slate-600">https://github.com/muralidharan84</div>
                  </div>
                </div>
                <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-lg">
                   {/* <Link href="https://www.linkedin.com/in/muralidharan-pakkirisamy"></Link> */}
                  <Linkedin className="w-6 h-6 text-blue-600" />
                  <div>
                    <div className="font-medium text-slate-900">LinkedIn</div>
                    <div className="text-slate-600">https://www.linkedin.com/in/muralidharan-pakkirisamy</div>
                    </div>
                </div>
              </div>
            </div>

            <Card className="border-slate-200 bg-white shadow-lg">
              <CardHeader className="pb-6">
                <CardTitle className="text-2xl text-slate-900">Send a Message</CardTitle>
                <CardDescription className="text-slate-600">I'll get back to you within 24 hours</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <Input placeholder="First Name" className="border-slate-300" />
                  <Input placeholder="Last Name" className="border-slate-300" />
                </div>
                <Input type="email" placeholder="Email Address" className="border-slate-300" />
                <Input placeholder="Subject" className="border-slate-300" />
                <Textarea
                  placeholder="Tell me about your project..."
                  rows={5}
                  className="border-slate-300 resize-none"
                />
                <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 text-base font-medium">
                  Send Message
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <footer className="bg-slate-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-6 md:mb-0">
              <div className="text-2xl font-bold mb-2">
                <Typewriter text="Muralidharan Pakkirisamy" speed={150} loop={true} />
              </div>
              <div className="text-slate-400">Senior Full-Stack Developer</div>
            </div>
            <div className="flex gap-4">
              <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white hover:bg-slate-800">
                <Github className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white hover:bg-slate-800">
                <Linkedin className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white hover:bg-slate-800">
                <Mail className="w-5 h-5" />
              </Button>
            </div>
          </div>
          <div className="border-t border-slate-800 mt-8 pt-8 text-center text-slate-400">
            © 2024 Muralidharan Pakkirisamy. All rights reserved. Built with Next.js and deployed on Vercel.
          </div>
        </div>
      </footer>
    </div>
  )
}
