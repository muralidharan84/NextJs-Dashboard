"use client"

import { useState, useEffect } from "react"

interface TypewriterProps {
  text: string
  speed?: number
  className?: string
  onComplete?: () => void
  loop?: boolean
}

export function Typewriter({ text, speed = 100, className = "", onComplete, loop = false }: TypewriterProps) {
  const [displayText, setDisplayText] = useState("")
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isDeleting, setIsDeleting] = useState(false)

  useEffect(() => {
    if (!loop) {
      // Original behavior for non-looping
      if (currentIndex < text.length) {
        const timeout = setTimeout(() => {
          setDisplayText((prev) => prev + text[currentIndex])
          setCurrentIndex((prev) => prev + 1)
        }, speed)
        return () => clearTimeout(timeout)
      } else if (onComplete) {
        onComplete()
      }
    } else {
      // New looping behavior
      if (!isDeleting && currentIndex < text.length) {
        // Typing phase
        const timeout = setTimeout(() => {
          setDisplayText((prev) => prev + text[currentIndex])
          setCurrentIndex((prev) => prev + 1)
        }, speed)
        return () => clearTimeout(timeout)
      } else if (!isDeleting && currentIndex === text.length) {
        // Pause before deleting
        const timeout = setTimeout(() => {
          setIsDeleting(true)
        }, 2000)
        return () => clearTimeout(timeout)
      } else if (isDeleting && displayText.length > 0) {
        // Deleting phase
        const timeout = setTimeout(() => {
          setDisplayText((prev) => prev.slice(0, -1))
        }, speed / 2)
        return () => clearTimeout(timeout)
      } else if (isDeleting && displayText.length === 0) {
        // Reset for next cycle
        setIsDeleting(false)
        setCurrentIndex(0)
      }
    }
  }, [currentIndex, text, speed, onComplete, loop, isDeleting, displayText])

  return (
    <span className={className}>
      {displayText}
      <span className="animate-pulse">|</span>
    </span>
  )
}
