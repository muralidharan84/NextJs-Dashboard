"use client"

import { Canvas } from "@react-three/fiber"
import { OrbitControls, Float, Text3D } from "@react-three/drei"
import { Suspense } from "react"

interface Icon3DProps {
  icon: string
  color?: string
  size?: number
  position?: [number, number, number]
}

function Icon3D({ icon, color = "#3b82f6", size = 0.5, position = [0, 0, 0] }: Icon3DProps) {
  return (
    <Float speed={1.5} rotationIntensity={0.5} floatIntensity={1}>
      <Text3D font="/fonts/Geist_Bold.json" size={size} height={0.1} position={position}>
        {icon}
        <meshStandardMaterial color={color} metalness={0.6} roughness={0.3} />
      </Text3D>
    </Float>
  )
}

export function CodeIcon3D() {
  return (
    <div className="w-20 h-20">
      <Canvas camera={{ position: [0, 0, 3] }}>
        <Suspense fallback={null}>
          <ambientLight intensity={0.5} />
          <directionalLight position={[2, 2, 2]} intensity={1} />
          <Icon3D icon="</>" color="#3b82f6" size={0.3} />
          <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={2} />
        </Suspense>
      </Canvas>
    </div>
  )
}

export function DatabaseIcon3D() {
  return (
    <div className="w-20 h-20">
      <Canvas camera={{ position: [0, 0, 3] }}>
        <Suspense fallback={null}>
          <ambientLight intensity={0.5} />
          <directionalLight position={[2, 2, 2]} intensity={1} />
          <Float speed={1.2} rotationIntensity={0.3} floatIntensity={0.8}>
            <mesh>
              <cylinderGeometry args={[0.6, 0.6, 0.3]} />
              <meshStandardMaterial color="#8b5cf6" metalness={0.7} roughness={0.2} />
            </mesh>
          </Float>
          <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={1.5} />
        </Suspense>
      </Canvas>
    </div>
  )
}

export function DesignIcon3D() {
  return (
    <div className="w-20 h-20">
      <Canvas camera={{ position: [0, 0, 3] }}>
        <Suspense fallback={null}>
          <ambientLight intensity={0.5} />
          <directionalLight position={[2, 2, 2]} intensity={1} />
          <Float speed={1.8} rotationIntensity={0.4} floatIntensity={1.2}>
            <mesh>
              <octahedronGeometry args={[0.5]} />
              <meshStandardMaterial color="#06b6d4" metalness={0.8} roughness={0.1} />
            </mesh>
          </Float>
          <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={2.5} />
        </Suspense>
      </Canvas>
    </div>
  )
}

export function EmailIcon3D() {
  return (
    <div className="w-16 h-16">
      <Canvas camera={{ position: [0, 0, 3] }}>
        <Suspense fallback={null}>
          <ambientLight intensity={0.5} />
          <directionalLight position={[2, 2, 2]} intensity={1} />
          <Float speed={1.0} rotationIntensity={0.2} floatIntensity={0.5}>
            <mesh>
              <boxGeometry args={[0.8, 0.5, 0.1]} />
              <meshStandardMaterial color="#3b82f6" metalness={0.5} roughness={0.4} />
            </mesh>
          </Float>
          <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={1} />
        </Suspense>
      </Canvas>
    </div>
  )
}

export function GithubIcon3D() {
  return (
    <div className="w-16 h-16">
      <Canvas camera={{ position: [0, 0, 3] }}>
        <Suspense fallback={null}>
          <ambientLight intensity={0.5} />
          <directionalLight position={[2, 2, 2]} intensity={1} />
          <Float speed={1.3} rotationIntensity={0.3} floatIntensity={0.7}>
            <mesh>
              <sphereGeometry args={[0.4]} />
              <meshStandardMaterial color="#1f2937" metalness={0.6} roughness={0.3} />
            </mesh>
          </Float>
          <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={1.5} />
        </Suspense>
      </Canvas>
    </div>
  )
}

export function LinkedinIcon3D() {
  return (
    <div className="w-16 h-16">
      <Canvas camera={{ position: [0, 0, 3] }}>
        <Suspense fallback={null}>
          <ambientLight intensity={0.5} />
          <directionalLight position={[2, 2, 2]} intensity={1} />
          <Float speed={1.1} rotationIntensity={0.25} floatIntensity={0.6}>
            <mesh>
              <boxGeometry args={[0.6, 0.6, 0.1]} />
              <meshStandardMaterial color="#0077b5" metalness={0.7} roughness={0.2} />
            </mesh>
          </Float>
          <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={1.2} />
        </Suspense>
      </Canvas>
    </div>
  )
}
