import * as React from 'react'

import { cn } from '@/lib/utils'

function Card({ className, ...props }: React.ComponentProps<'div'>) {
  return (
    <div
      data-slot="card"
      className={cn(
        'bg-card text-card-foreground flex flex-col gap-6 rounded-xl border py-6 shadow-sm',
        className,
      )}
      {...props}
    />
  )
}

function CardHeader({ className, ...props }: React.ComponentProps<'div'>) {
  return (
    <div
      data-slot="card-header"
      className={cn(
        '@container/card-header grid auto-rows-min grid-rows-[auto_auto] items-start gap-1.5 px-6 has-data-[slot=card-action]:grid-cols-[1fr_auto] [.border-b]:pb-6',
        className,
      )}
      {...props}
    />
  )
}

function CardTitle({ className, ...props }: React.ComponentProps<'div'>) {
  return (
    <div
      data-slot="card-title"
      className={cn('leading-none font-semibold', className)}
      {...props}
    />
  )
}
function CardSubTitle1({ className, ...props }: React.ComponentProps<'div'>) {
  return (
    <div
      data-slot="card-subtitle"
      className={cn('leading-none font-semibold', className)}
      {...props}
    />
  )
}
function CardSubTitle({ className, items=[], ...props }: React.ComponentProps<'div'> & {items?: string[]}) {
  return (
    <div
      data-slot="card-subtitle"
      className={cn('flex justify-between leading-none font-semibold', className)}
      {...props}
    ><span>{items[0]}</span>
      {items[1] && <span>{items[1]}</span>}</div>
  )
}

// function CardDescription({ className, ...props }: React.ComponentProps<'div'>) {
//   return (
//     <div
//       data-slot="card-description"
//       className={cn('text-muted-foreground text-sm', className)}
//       {...props}
//     />
//   )
// }

function CardDescription({
  className,
  items = [],
  ...props
}: React.ComponentProps<'ul'> & { items?: string[] }) {
  debugger;
  return (
    <ul
      data-slot="card-description"
      className={cn('text-muted-foreground text-sm list-disc list-inside', className)}
      {...props}
    >
      {items.map((item, index) => (
        <li key={index}>{item}</li>
      ))}
    </ul>
  )
}

function CardAction({ className, ...props }: React.ComponentProps<'div'>) {
  return (
    <div
      data-slot="card-action"
      className={cn(
        'col-start-2 row-span-2 row-start-1 self-start justify-self-end',
        className,
      )}
      {...props}
    />
  )
}

function CardContent({ className, ...props }: React.ComponentProps<'div'>) {
  return (
    <div
      data-slot="card-content"
      className={cn('px-6', className)}
      {...props}
    />
  )
}

function CardFooter({ className, ...props }: React.ComponentProps<'div'>) {
  return (
    <div
      data-slot="card-footer"
      className={cn('flex items-center px-6 [.border-t]:pt-6', className)}
      {...props}
    />
  )
}

export {
  Card,
  CardHeader,
  CardFooter,
  CardTitle,
  CardSubTitle1,
  CardSubTitle,
  CardAction,
  CardDescription,
  CardContent,
}
